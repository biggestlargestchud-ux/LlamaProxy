@echo off
setlocal

REM Remove only this script's folder from the current user's PATH.
REM Other User PATH entries are preserved.
set "LLAMA_DIR=%~dp0"

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference = 'Stop'; $dir = [IO.Path]::GetFullPath($env:LLAMA_DIR).TrimEnd('\'); $old = [Environment]::GetEnvironmentVariable('Path', 'User'); if ([string]::IsNullOrEmpty($old)) { Write-Output 'User PATH is already empty.'; exit 0 }; $parts = @($old -split ';' | Where-Object { $_.Trim() -ne '' }); $kept = @(); $removed = 0; foreach ($p in $parts) { $candidate = $p.Trim().Trim([char]34).TrimEnd('\'); if ([string]::Equals($candidate, $dir, [StringComparison]::OrdinalIgnoreCase)) { $removed++ } else { $kept += $p } }; if ($removed -gt 0) { [Environment]::SetEnvironmentVariable('Path', ($kept -join ';'), 'User'); Write-Output ('Removed from User PATH: ' + $dir) } else { Write-Output ('No matching entry found in User PATH: ' + $dir) }"

if errorlevel 1 (
    echo.
    echo ERROR: Could not update User PATH.
    pause
    exit /b 1
)

echo.
echo Done. Open a NEW terminal window for the change to take effect.
echo Other User PATH entries were left unchanged.
echo.
pause
endlocal
