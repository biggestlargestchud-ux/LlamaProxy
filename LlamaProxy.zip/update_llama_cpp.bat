@echo off
setlocal
title Update llama.cpp

REM Update the llama.cpp Windows build in the same folder as this script.
REM Downloads official release assets from ggml-org/llama.cpp only.
set "LLAMA_DIR=%~dp0"
set "LLAMA_EXE=%LLAMA_DIR%llama-server.exe"

if not exist "%LLAMA_EXE%" (
    echo ERROR: llama-server.exe was not found in:
    echo   "%LLAMA_DIR%"
    echo.
    echo Put this BAT file in the same folder as your llama.cpp files.
    pause
    exit /b 1
)

echo.
echo Checking the official ggml-org/llama.cpp releases...
echo This updater keeps model files and unrelated files untouched.
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
 "$ErrorActionPreference='Stop';" ^
 "$dir=[IO.Path]::GetFullPath($env:LLAMA_DIR);" ^
 "$exe=Join-Path $dir 'llama-server.exe';" ^
 "$exeBytes=[IO.File]::ReadAllBytes($exe);" ^
 "$peOffset=[BitConverter]::ToInt32($exeBytes,0x3c); $machine=[BitConverter]::ToUInt16($exeBytes,$peOffset+4);" ^
 "$arch=switch($machine){ 0x8664 {'x64'} 0x14c {'x86'} 0xaa64 {'ARM64'} default {'Unknown (PE machine 0x{0:X4}' -f $machine} };" ^
 "$binaryText=[Text.Encoding]::ASCII.GetString($exeBytes);" ^
 "$tagFile=Join-Path $dir '.llama-cpp-release-tag.txt';" ^
 "$api='https://api.github.com/repos/ggml-org/llama.cpp/releases?per_page=30';" ^
 "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;" ^
 "$headers=@{ 'User-Agent'='llama-cpp-local-updater'; 'Accept'='application/vnd.github+json' };" ^
 "$releases=Invoke-RestMethod -Uri $api -Headers $headers;" ^
 "$backend='cpu'; $backendEvidence='No GPU backend markers found in executable; treating as CPU build';" ^
 "if($binaryText -match '(?i)ggml-cuda|cudart64|cublas64|nvrtc64') { $backend='cuda'; $backendEvidence='CUDA-related imports/strings in llama-server.exe' }" ^
 "elseif($binaryText -match '(?i)ggml-vulkan|vulkan-1\.dll') { $backend='vulkan'; $backendEvidence='Vulkan-related imports/strings in llama-server.exe' }" ^
 "elseif($binaryText -match '(?i)ggml-sycl|sycl[0-9]*\.dll|ze_loader\.dll') { $backend='sycl'; $backendEvidence='SYCL/Level Zero-related imports/strings in llama-server.exe' }" ^
 "elseif($binaryText -match '(?i)ggml-hip|amdhip|hipblas|rocblas') { $backend='rocm'; $backendEvidence='HIP/ROCm-related imports/strings in llama-server.exe' }" ^
 "else {" ^
 " if(Test-Path (Join-Path $dir 'ggml-cuda.dll')) { $backend='cuda'; $backendEvidence='ggml-cuda.dll beside executable (fallback)' }" ^
 " elseif(Test-Path (Join-Path $dir 'ggml-vulkan.dll')) { $backend='vulkan'; $backendEvidence='ggml-vulkan.dll beside executable (fallback)' }" ^
 " elseif(Test-Path (Join-Path $dir 'ggml-sycl.dll')) { $backend='sycl'; $backendEvidence='ggml-sycl.dll beside executable (fallback)' }" ^
 " elseif(Test-Path (Join-Path $dir 'ggml-hip.dll')) { $backend='rocm'; $backendEvidence='ggml-hip.dll beside executable (fallback)' }" ^
 " }" ^
 "Write-Host ('Current llama-server.exe architecture: '+$arch);" ^
 "Write-Host ('Current llama-server.exe backend/type: '+$backend);" ^
 "Write-Host ('Detection evidence: '+$backendEvidence);" ^
 "try { $gpus=@(Get-CimInstance Win32_VideoController -ErrorAction Stop | Select-Object -ExpandProperty Name -Unique); if($gpus.Count){ Write-Host 'Detected display hardware:'; $gpus | ForEach-Object { Write-Host ('  '+$_) } } } catch { Write-Host 'GPU hardware information is unavailable on this system.' }" ^
 "$candidates=@();" ^
 "foreach($r in $releases) {" ^
 " $a=@($r.assets | Where-Object { $_.name -match '(?i)bin-win' -and $_.name -match '(?i)x64' -and $_.name -match '(?i)\.zip$' });" ^
 " if($backend -eq 'cpu') { $a=@($a | Where-Object { $_.name -match '(?i)cpu' -and $_.name -notmatch '(?i)cudart' }) }" ^
 " elseif($backend -eq 'cuda') { $a=@($a | Where-Object { $_.name -match '(?i)cuda' -and $_.name -notmatch '(?i)cudart' }) }" ^
 " elseif($backend -eq 'vulkan') { $a=@($a | Where-Object { $_.name -match '(?i)vulkan' }) }" ^
 " elseif($backend -eq 'sycl') { $a=@($a | Where-Object { $_.name -match '(?i)sycl' }) }" ^
 " elseif($backend -eq 'rocm') { $a=@($a | Where-Object { $_.name -match '(?i)rocm' }) }" ^
 " if($a.Count -gt 0) { $candidates += [pscustomobject]@{Release=$r;Assets=$a}; break }" ^
 "}" ^
 "if($candidates.Count -eq 0) { throw ('No matching official Windows x64 '+$backend+' ZIP asset was found in the recent releases. Check the official releases page.') }" ^
 "$release=$candidates[0].Release; $assets=@($candidates[0].Assets);" ^
 "if($assets.Count -gt 1) {" ^
 " Write-Host 'More than one matching package was found:';" ^
 " for($i=0;$i -lt $assets.Count;$i++){ Write-Host ('  '+($i+1)+'. '+$assets[$i].name) }" ^
 " $choice=Read-Host 'Choose package number'; $n=0;" ^
 " if(-not [int]::TryParse($choice,[ref]$n) -or $n -lt 1 -or $n -gt $assets.Count){ throw 'Invalid package selection.' }" ^
 " $asset=$assets[$n-1]" ^
 "} else { $asset=$assets[0] }" ^
 "$remoteTag=[string]$release.tag_name;" ^
 "$localTag=''; if(Test-Path $tagFile){$localTag=(Get-Content $tagFile -Raw).Trim()}" ^
 "Write-Host ('Official release: '+$remoteTag+' ('+$asset.name+')');" ^
 "if($localTag -eq $remoteTag) { Write-Host 'Already up to date. No files were changed.'; exit 0 }" ^
 "if($localTag) { Write-Host ('Recorded local release: '+$localTag) } else { Write-Host 'No updater version record exists yet; the current folder version cannot be reliably identified.' }" ^
 "$answer=Read-Host 'Download and install this release into this folder? (Y/N)'; if($answer -notmatch '^(?i)y(es)?$'){ Write-Host 'Cancelled. No files were changed.'; exit 0 }" ^
 "$running=Get-Process -Name 'llama-server' -ErrorAction SilentlyContinue; if($running){ throw 'llama-server.exe is running. Stop the server and run this updater again.' }" ^
 "$work=Join-Path $dir ('.llama-update-'+[guid]::NewGuid().ToString('N'));" ^
 "$zip=Join-Path $work $asset.name; $extract=Join-Path $work 'extracted'; New-Item -ItemType Directory -Path $extract -Force | Out-Null;" ^
 "try {" ^
 " Write-Host 'Downloading from the official GitHub release...';" ^
 " Invoke-WebRequest -Uri $asset.browser_download_url -OutFile $zip -Headers $headers;" ^
 " Expand-Archive -LiteralPath $zip -DestinationPath $extract -Force;" ^
 " $files=@(Get-ChildItem -LiteralPath $extract -Recurse -File);" ^
 " if(-not ($files | Where-Object { $_.Name -ieq 'llama-server.exe' })) { throw 'The downloaded package does not contain llama-server.exe. Nothing was installed.' }" ^
 " $backup=Join-Path $dir ('llama-backup-'+(Get-Date -Format 'yyyyMMdd-HHmmss'));" ^
 " $copied=0;" ^
 " foreach($f in $files) {" ^
 "  $relative=$f.FullName.Substring($extract.TrimEnd('\').Length).TrimStart('\');" ^
 "  $dest=Join-Path $dir $relative;" ^
 "  if(Test-Path $dest -PathType Leaf) { $old=$dest.Substring($dir.TrimEnd('\').Length).TrimStart('\'); $backupFile=Join-Path $backup $old; New-Item -ItemType Directory -Path (Split-Path $backupFile -Parent) -Force | Out-Null; Copy-Item -LiteralPath $dest -Destination $backupFile -Force }" ^
 "  New-Item -ItemType Directory -Path (Split-Path $dest -Parent) -Force | Out-Null;" ^
 "  Copy-Item -LiteralPath $f.FullName -Destination $dest -Force; $copied++" ^
 " }" ^
 " Set-Content -LiteralPath $tagFile -Value $remoteTag -Encoding ASCII;" ^
 " Write-Host ''; Write-Host ('SUCCESS: updated to '+$remoteTag);" ^
 " Write-Host ('Updated package files: '+$copied);" ^
 " if(Test-Path $backup){Write-Host ('Previous matching files backed up to: '+$backup)}" ^
 " Write-Host 'Your model files and unrelated files were not deleted.';" ^
 "} finally { if(Test-Path $work){Remove-Item -LiteralPath $work -Recurse -Force -ErrorAction SilentlyContinue} }"

if errorlevel 1 (
    echo.
    echo ERROR: Update failed. Review the message above.
    echo Your existing files were not intentionally deleted.
    pause
    exit /b 1
)

echo.
pause
endlocal
