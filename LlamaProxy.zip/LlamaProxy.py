#!/usr/bin/env python3
r"""Start llama.cpp with a local model, expose an API-key-protected proxy, and test-chat.

Requirements:
  - Python 3.9+
  - A llama.cpp `llama-server` executable available on PATH, or pass --llama-server.
  - Select a GGUF model with the file picker, or pass --model for a non-interactive launch.

Examples (PowerShell):
  python .\LlamaProxy.py
  python .\LlamaProxy.py --llama-server "C:\\llama.cpp\\llama-server.exe"
  python .\LlamaProxy.py --model "C:\\path\\to\\model.gguf" --no-chat

The proxy listens on http://127.0.0.1:8000 by default. Use the printed API key
as either `Authorization: Bearer <key>` or `X-API-Key: <key>`, or just simply
paste the entire API key into Janitor AI's API key box. Do not share your API
key. Please.
"""

from __future__ import annotations

import argparse
import http.client
import json
import os
import secrets
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Optional

DEFAULT_MODEL_DIR = Path.home()
DEFAULT_SYSTEM_PROMPT = "You are a helpful assistant."
DEFAULT_CORS_ORIGINS = ("https://janitorai.com",)


def format_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            return f"{value:.1f} {unit}"
        value /= 1024
    return f"{value:.1f} TB"


def scan_models(model_dir: Path) -> list[Path]:
    """Return GGUF files recursively, sorted by relative path."""
    if not model_dir.exists():
        raise FileNotFoundError(f"Model directory does not exist: {model_dir}")
    if not model_dir.is_dir():
        raise NotADirectoryError(f"Model path is not a directory: {model_dir}")

    models: list[Path] = []
    for path in model_dir.rglob("*"):
        try:
            if path.is_file() and path.suffix.lower() == ".gguf":
                models.append(path)
        except OSError:
            # Ignore inaccessible entries and continue scanning other folders.
            continue
    return sorted(models, key=lambda item: str(item).casefold())


def choose_model(model_dir: Path, requested_model: Optional[str]) -> Path:
    """Choose a GGUF model using a native file picker, with a terminal fallback."""
    if requested_model:
        model = Path(requested_model).expanduser()
        if not model.is_file():
            raise FileNotFoundError(f"Model file not found: {model}")
        if model.suffix.lower() != ".gguf":
            raise ValueError("llama.cpp model selection expects a .gguf file.")
        return model.resolve()

    # Prefer a native file picker. The starting directory is only a convenience;
    # the user can browse to any folder or drive.
    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        try:
            root.attributes("-topmost", True)
        except Exception:
            pass

        selected = filedialog.askopenfilename(
            parent=root,
            title="Select a llama.cpp GGUF model",
            initialdir=str(model_dir.expanduser()) if model_dir.expanduser().is_dir() else str(Path.home()),
            filetypes=[
                ("GGUF model files", "*.gguf"),
                ("All files", "*.*"),
            ],
        )
        root.destroy()

        if not selected:
            raise SystemExit("Model selection cancelled.")
        model = Path(selected).expanduser()
        if not model.is_file():
            raise FileNotFoundError(f"Model file not found: {model}")
        if model.suffix.lower() != ".gguf":
            raise ValueError("Please select a .gguf model file.")
        return model.resolve()

    except SystemExit:
        raise
    except Exception as exc:
        print(f"\\n[model picker] Desktop file picker unavailable ({exc}).")
        print("Enter the full path to a .gguf model file instead.")

    while True:
        answer = input("GGUF model path (or Q to quit): ").strip().strip('"')
        if answer.casefold() in {"q", "quit", "exit"}:
            raise SystemExit(0)
        model = Path(answer).expanduser()
        if model.is_file() and model.suffix.lower() == ".gguf":
            return model.resolve()
        print("That file was not found or is not a .gguf file. Try again.")


def choose_context_size(default_value: int, slider_max: int = 131072) -> int:
    """Show a Tkinter context slider with a numeric entry before starting llama.cpp.

    If Tkinter is unavailable (or no desktop display exists), fall back to a
    validated terminal prompt. The entry accepts values between 512 and 1,048,576.
    """
    minimum = 512
    absolute_maximum = 1_048_576
    slider_max = max(minimum, min(int(slider_max), absolute_maximum))
    initial = max(minimum, min(int(default_value), absolute_maximum))

    try:
        import tkinter as tk
        from tkinter import ttk

        root = tk.Tk()
        root.title("Choose Model Context")
        root.resizable(False, False)

        frame = ttk.Frame(root, padding=16)
        frame.grid(row=0, column=0, sticky="nsew")

        ttk.Label(
            frame,
            text="Choose how many context tokens the model can use",
            font=("Segoe UI", 11, "bold"),
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))

        value_var = tk.StringVar(value=str(initial))
        slider_var = tk.IntVar(value=min(initial, slider_max))
        updating = {"entry": False, "slider": False}

        ttk.Label(frame, text="Context size (tokens):").grid(
            row=1, column=0, sticky="w", padx=(0, 8)
        )
        entry = ttk.Entry(frame, textvariable=value_var, width=14)
        entry.grid(row=1, column=1, sticky="w")

        ttk.Label(
            frame,
            text=f"Slider range: {minimum:,}–{slider_max:,} tokens",
        ).grid(row=2, column=0, columnspan=3, sticky="w", pady=(12, 2))

        def slider_changed(raw_value):
            if updating["entry"]:
                return
            updating["slider"] = True
            value_var.set(str(int(float(raw_value))))
            updating["slider"] = False

        def entry_changed(*_):
            if updating["slider"]:
                return
            raw = value_var.get().strip().replace(",", "")
            if raw.isdigit():
                number = int(raw)
                if minimum <= number <= slider_max:
                    updating["entry"] = True
                    slider_var.set(number)
                    updating["entry"] = False

        slider = tk.Scale(
            frame,
            from_=minimum,
            to=slider_max,
            orient="horizontal",
            resolution=512,
            variable=slider_var,
            length=420,
            showvalue=True,
            command=slider_changed,
        )
        slider.grid(row=3, column=0, columnspan=3, sticky="ew")
        value_var.trace_add("write", entry_changed)

        ttk.Label(
            frame,
            text=(
                "Larger context uses more RAM/VRAM. Start modestly; "
                "the model and your hardware determine what is practical."
            ),
            wraplength=420,
        ).grid(row=4, column=0, columnspan=3, sticky="w", pady=(8, 12))

        selected = {"value": None}

        def confirm():
            raw = value_var.get().strip().replace(",", "")
            try:
                number = int(raw)
            except ValueError:
                error_var.set("Enter a whole number of tokens.")
                return
            if not minimum <= number <= absolute_maximum:
                error_var.set(f"Choose a value from {minimum:,} to {absolute_maximum:,}.")
                return
            selected["value"] = number
            root.destroy()

        def cancel():
            root.destroy()

        error_var = tk.StringVar(value="")
        ttk.Label(frame, textvariable=error_var, foreground="red").grid(
            row=5, column=0, columnspan=3, sticky="w"
        )
        buttons = ttk.Frame(frame)
        buttons.grid(row=6, column=0, columnspan=3, sticky="e", pady=(8, 0))
        ttk.Button(buttons, text="Cancel", command=cancel).pack(side="right", padx=(8, 0))
        ttk.Button(buttons, text="Use this context", command=confirm).pack(side="right")

        root.protocol("WM_DELETE_WINDOW", cancel)
        root.bind("<Return>", lambda _event: confirm())
        root.bind("<Escape>", lambda _event: cancel())
        root.mainloop()

        if selected["value"] is None:
            raise SystemExit("Context selection cancelled.")
        return selected["value"]

    except SystemExit:
        raise
    except Exception as exc:
        print(f"\n[context picker] Desktop slider unavailable ({exc}).")
        print("Use the terminal input below instead.")

    while True:
        answer = input(
            f"Context size in tokens [{initial:,}] "
            f"(whole number, {minimum:,}–{absolute_maximum:,}; Enter keeps default): "
        ).strip().replace(",", "")
        if not answer:
            return initial
        try:
            number = int(answer)
        except ValueError:
            print("Please enter a whole number.")
            continue
        if minimum <= number <= absolute_maximum:
            return number
        print(f"Choose a value from {minimum:,} to {absolute_maximum:,}.")

def resolve_server_executable(value: str) -> str:
    located = shutil.which(value)
    if located:
        return located
    candidate = Path(value).expanduser()
    if candidate.is_file():
        return str(candidate.resolve())
    raise FileNotFoundError(
        f"Could not find llama-server executable: {value}\n"
        "Install/build llama.cpp and put llama-server.exe on PATH, or pass "
        '--llama-server "C:\\path\\to\\llama-server.exe".'
    )


def wait_for_upstream(process: subprocess.Popen, host: str, port: int, timeout: int = 180) -> None:
    """Wait until llama-server responds to /health or /v1/models."""
    base = f"http://{host}:{port}"
    deadline = time.monotonic() + timeout
    last_error = "server is still starting"

    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(
                f"llama-server exited early with code {process.returncode}. "
                "Review the llama.cpp output above for details."
            )

        for endpoint in ("/health", "/v1/models"):
            try:
                request = urllib.request.Request(base + endpoint, method="GET")
                with urllib.request.urlopen(request, timeout=2) as response:
                    if 200 <= response.status < 500:
                        return
            except urllib.error.HTTPError as exc:
                # A reachable endpoint returning an HTTP error still proves the server is up.
                if exc.code < 500:
                    return
                last_error = f"HTTP {exc.code} from {endpoint}"
            except Exception as exc:  # connection errors while the model is loading
                last_error = str(exc)
        time.sleep(1)

    raise TimeoutError(
        f"llama-server did not become ready within {timeout} seconds ({last_error})."
    )


def fetch_model_id(host: str, port: int, timeout: int = 10) -> str:
    """Return the model ID reported by llama.cpp at /v1/models."""
    url = f"http://{host}:{port}/v1/models"
    request = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))

    models = payload.get("data", [])
    if not models or not isinstance(models[0], dict) or not models[0].get("id"):
        raise RuntimeError(f"llama.cpp returned no model ID from {url}: {payload!r}")
    return str(models[0]["id"])


def fetch_context_info(host: str, port: int, timeout: int = 10) -> dict:
    """Read the loaded runtime context from llama.cpp's GET /props endpoint.

    `default_generation_settings.n_ctx` is the server-reported context setting.
    This is the active runtime context, not necessarily the model's original
    training-context limit recorded in its architecture metadata.
    """
    url = f"http://{host}:{port}/props"
    request = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        payload = json.loads(response.read().decode("utf-8"))

    if not isinstance(payload, dict):
        raise RuntimeError(f"Unexpected response from {url}: expected a JSON object")

    generation_settings = payload.get("default_generation_settings") or {}
    n_ctx = generation_settings.get("n_ctx")
    if isinstance(n_ctx, bool):
        n_ctx = None
    try:
        n_ctx = int(n_ctx) if n_ctx is not None else None
    except (TypeError, ValueError):
        n_ctx = None

    if n_ctx is None or n_ctx <= 0:
        raise RuntimeError(
            f"{url} did not report a positive default_generation_settings.n_ctx value"
        )

    total_slots = payload.get("total_slots")
    try:
        total_slots = int(total_slots) if total_slots is not None else None
    except (TypeError, ValueError):
        total_slots = None

    return {
        "n_ctx": n_ctx,
        "total_slots": total_slots,
        "model_path": payload.get("model_path"),
        "build_info": payload.get("build_info"),
        "modalities": payload.get("modalities"),
    }


def print_context_scan(context_info: Optional[dict], requested_ctx: int) -> None:
    """Print the context scanner's startup report."""
    print("\nContext Window Scanner")
    print("-" * 58)
    print(f"Requested --ctx-size: {requested_ctx:,} tokens")
    if context_info is None:
        print("Loaded runtime context: unavailable (llama.cpp /props did not report n_ctx)")
        print("The requested value above is not being presented as a verified loaded value.")
        return

    print(f"Loaded runtime context (n_ctx): {context_info['n_ctx']:,} tokens")
    if context_info.get("total_slots") is not None:
        print(f"Server slots: {context_info['total_slots']}")
    if context_info.get("model_path"):
        print(f"Server model path: {context_info['model_path']}")
    if context_info.get("build_info"):
        print(f"llama.cpp build: {context_info['build_info']}")
    print("Note: n_ctx is the active server context setting; the model's native training limit may differ.")


def make_proxy_handler(
    upstream_host: str,
    upstream_port: int,
    api_key: str,
    cors_origins: Optional[tuple[str, ...]] = None,
):
    allowed_origins = set(cors_origins or DEFAULT_CORS_ORIGINS)
    excluded_response_headers = {
        "content-length", "transfer-encoding", "connection", "keep-alive",
        "content-encoding", "server", "date", "upgrade", "trailer",
        "access-control-allow-origin", "access-control-allow-credentials",
        "access-control-allow-headers", "access-control-allow-methods",
        "access-control-expose-headers", "access-control-max-age",
        "access-control-allow-private-network", "vary",
    }
    class APIKeyProxyHandler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "llama-cpp-api-key-proxy/1.0"

        def log_message(self, fmt: str, *args) -> None:
            # Keep the normal access log, but never print request headers or API keys.
            super().log_message(fmt, *args)

        def add_cors_headers(self) -> None:
            # Return exactly one origin value, and only for explicitly allowed sites.
            # Do not use '*' here: Janitor AI accesses this loopback server from a
            # public HTTPS origin, and the proxy must not duplicate upstream CORS.
            origin = self.headers.get("Origin", "").strip()
            if origin not in allowed_origins:
                return

            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
            self.send_header(
                "Access-Control-Allow-Headers",
                "Authorization, Content-Type, X-API-Key, Accept, Origin, Cache-Control, Pragma",
            )
            self.send_header("Access-Control-Expose-Headers", "Content-Type, X-Request-ID")
            self.send_header("Access-Control-Max-Age", "86400")
            self.send_header("Vary", "Origin")
            # Chromium's Private Network Access preflight may request this explicitly.
            if self.headers.get("Access-Control-Request-Private-Network", "").lower() == "true":
                self.send_header("Access-Control-Allow-Private-Network", "true")

        def send_json(self, status: int, payload: dict) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.add_cors_headers()
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if body:
                self.wfile.write(body)

        def supplied_key(self) -> str:
            authorization = self.headers.get("Authorization", "")
            if authorization.lower().startswith("bearer "):
                return authorization[7:].strip()
            return self.headers.get("X-API-Key", "").strip()

        def authorized(self) -> bool:
            import hmac
            return hmac.compare_digest(self.supplied_key(), api_key)

        def do_GET(self) -> None:
            if self.path.split("?", 1)[0] == "/health":
                self.send_json(200, {"status": "ok", "proxy": "llama.cpp"})
                return
            self.handle_proxy_request()

        def do_POST(self) -> None:
            self.handle_proxy_request()

        def do_PUT(self) -> None:
            self.handle_proxy_request()

        def do_PATCH(self) -> None:
            self.handle_proxy_request()

        def do_DELETE(self) -> None:
            self.handle_proxy_request()

        def do_OPTIONS(self) -> None:
            # Preflight requests must be answered before API-key authentication:
            # browsers do not include the actual Authorization value in preflight.
            self.send_response(204)
            self.add_cors_headers()
            self.send_header("Allow", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
            self.send_header("Content-Length", "0")
            self.end_headers()

        def handle_proxy_request(self) -> None:
            route = self.path.split("?", 1)[0]
            if not route.startswith("/v1/"):
                self.send_json(404, {"error": {"message": "Only /v1/* API routes and /health are available."}})
                return
            if not self.authorized():
                self.send_json(401, {"error": {"message": "Missing or invalid API key."}})
                return

            try:
                raw_length = self.headers.get("Content-Length", "0")
                body_length = int(raw_length)
                if body_length < 0:
                    raise ValueError("negative Content-Length")
                body = self.rfile.read(body_length) if body_length else None
            except (ValueError, OSError):
                self.send_json(400, {"error": {"message": "Invalid request body."}})
                return

            # Forward ordinary end-to-end headers only. The upstream is local, so the
            # public API key is deliberately not forwarded to llama-server.
            excluded = {
                "host", "authorization", "x-api-key", "connection", "keep-alive",
                "proxy-authenticate", "proxy-authorization", "te", "trailers",
                "transfer-encoding", "upgrade", "content-length", "expect",
                "accept-encoding",
            }
            upstream_headers = {
                name: value for name, value in self.headers.items()
                if name.lower() not in excluded
            }
            upstream_headers["Accept-Encoding"] = "identity"
            if body is not None:
                upstream_headers["Content-Length"] = str(len(body))

            stream_response = False
            content_type = self.headers.get("Content-Type", "")
            if body and "application/json" in content_type.lower():
                try:
                    stream_response = bool(json.loads(body.decode("utf-8")).get("stream", False))
                except (UnicodeDecodeError, json.JSONDecodeError, AttributeError):
                    stream_response = False

            connection = http.client.HTTPConnection(upstream_host, upstream_port, timeout=600)
            response_started = False
            try:
                connection.request(self.command, self.path, body=body, headers=upstream_headers)
                response = connection.getresponse()

                if stream_response:
                    # Once response headers are sent, a later stream error cannot be
                    # converted into a second HTTP status (for example, 200 then 502).
                    response_started = True
                    self.send_response(response.status, response.reason)
                    self.add_cors_headers()
                    for name, value in response.getheaders():
                        if name.lower() not in excluded_response_headers:
                            self.send_header(name, value)
                    self.send_header("Transfer-Encoding", "chunked")
                    self.send_header("Connection", "close")
                    self.end_headers()
                    self.close_connection = True

                    while True:
                        chunk = response.read1(8192) if hasattr(response, "read1") else response.read(8192)
                        if not chunk:
                            break
                        self.wfile.write(f"{len(chunk):X}\r\n".encode("ascii"))
                        self.wfile.write(chunk)
                        self.wfile.write(b"\r\n")
                        self.wfile.flush()
                    self.wfile.write(b"0\r\n\r\n")
                    self.wfile.flush()
                else:
                    response_body = response.read()
                    response_started = True
                    self.send_response(response.status, response.reason)
                    self.add_cors_headers()
                    for name, value in response.getheaders():
                        if name.lower() not in excluded_response_headers:
                            self.send_header(name, value)
                    self.send_header("Content-Length", str(len(response_body)))
                    self.end_headers()
                    if response_body:
                        self.wfile.write(response_body)
            except (OSError, http.client.HTTPException) as exc:
                if response_started:
                    # The client may have disconnected, or forwarding failed after
                    # headers were committed. Log the cause; never emit a second status.
                    print(
                        f"[proxy] response stream interrupted after headers were sent: {exc}",
                        file=sys.stderr,
                    )
                    self.close_connection = True
                else:
                    try:
                        self.send_json(502, {"error": {"message": f"Upstream llama-server error: {exc}"}})
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        self.close_connection = True

            finally:
                connection.close()

    return APIKeyProxyHandler


def start_chat_test(
    proxy_host: str, proxy_port: int, api_key: str, system_prompt: str, model_id: str
) -> None:
    """Small terminal chat client that talks through the protected proxy."""
    # Connect through loopback even if the proxy is bound to 0.0.0.0.
    client_host = "127.0.0.1" if proxy_host in {"0.0.0.0", "::"} else proxy_host
    endpoint = f"http://{client_host}:{proxy_port}/v1/chat/completions"
    messages = [{"role": "system", "content": system_prompt}]

    print("\nInteractive chat test")
    print("Type a message and press Enter. Commands: /reset, /exit")
    print("-" * 58)

    while True:
        try:
            prompt = input("\nYou: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return

        if not prompt:
            continue
        if prompt.casefold() in {"/exit", "/quit"}:
            return
        if prompt.casefold() == "/reset":
            messages = [{"role": "system", "content": system_prompt}]
            print("Conversation reset.")
            continue

        messages.append({"role": "user", "content": prompt})
        payload = json.dumps({
            "model": model_id,
            "messages": messages,
            "stream": False,
        }).encode("utf-8")
        request = urllib.request.Request(
            endpoint,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=600) as response:
                result = json.loads(response.read().decode("utf-8"))
            answer = result["choices"][0]["message"]["content"]
            if isinstance(answer, list):
                answer = "".join(
                    item.get("text", "") if isinstance(item, dict) else str(item)
                    for item in answer
                )
            print(f"\nBot: {answer}")
            messages.append({"role": "assistant", "content": answer})
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            print(f"\nAPI error ({exc.code}): {detail}")
            messages.pop()  # Don't retain a user message that did not get an answer.
        except (urllib.error.URLError, TimeoutError, KeyError, IndexError, json.JSONDecodeError) as exc:
            print(f"\nChat request failed: {exc}")
            messages.pop()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Launch llama.cpp, expose an API-key-protected OpenAI-compatible proxy, and chat-test it."
    )
    parser.add_argument("--model-dir", default=str(DEFAULT_MODEL_DIR), help="Optional starting folder shown in the GGUF file picker (not a required model location).")
    parser.add_argument("--model", help="Path to a specific .gguf model; skips the file picker.")
    parser.add_argument(
        "--llama-server",
        default=os.environ.get("LLAMA_SERVER", "llama-server"),
        help="llama-server executable path or command name (or set LLAMA_SERVER).",
    )
    parser.add_argument("--upstream-host", default="127.0.0.1", help="Private llama-server bind address.")
    parser.add_argument("--upstream-port", type=int, default=8081, help="Private llama-server port.")
    parser.add_argument("--proxy-host", default="127.0.0.1", help="Proxy bind address; use 0.0.0.0 only on trusted networks.")
    parser.add_argument("--proxy-port", type=int, default=8000, help="Public proxy port.")
    parser.add_argument("--api-key", default=os.environ.get("LLAMA_PROXY_API_KEY"), help="API key (or set LLAMA_PROXY_API_KEY); generated if omitted.")
    parser.add_argument("--cors-origin", action="append", dest="cors_origins", help="Additional allowed browser origin; may be repeated. Janitor AI origins are allowed by default.")
    parser.add_argument("--ctx-size", type=int, default=None, help="Context size passed to llama-server; if omitted, a slider appears before startup.")
    parser.add_argument("--ctx-slider-max", type=int, default=131072, help="Maximum value shown on the context slider (default: 131072).")
    parser.add_argument("--n-gpu-layers", type=int, default=99, help="GPU layers passed to llama-server; use 0 for CPU-only.")
    parser.add_argument("--threads", type=int, help="Optional CPU thread count passed to llama-server.")
    parser.add_argument("--startup-timeout", type=int, default=180, help="Seconds to wait for the model server to become ready.")
    parser.add_argument("--system-prompt", default=DEFAULT_SYSTEM_PROMPT, help="System prompt used by the terminal chat test.")
    parser.add_argument("--no-chat", action="store_true", help="Run only the API proxy; do not start the interactive chat test.")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    process: Optional[subprocess.Popen] = None
    proxy: Optional[ThreadingHTTPServer] = None
    proxy_thread: Optional[threading.Thread] = None

    try:
        model = choose_model(Path(args.model_dir).expanduser(), args.model)
        server_executable = resolve_server_executable(args.llama_server)
        # The context picker runs before llama-server starts. An explicit --ctx-size
        # bypasses the picker for scripted/headless launches.
        if args.ctx_size is None:
            args.ctx_size = choose_context_size(4096, args.ctx_slider_max)
        elif not 512 <= args.ctx_size <= 1_048_576:
            raise ValueError("--ctx-size must be between 512 and 1,048,576 tokens.")
        api_key = args.api_key or secrets.token_urlsafe(32)

        command = [
            server_executable,
            "--model", str(model),
            "--host", args.upstream_host,
            "--port", str(args.upstream_port),
            "--ctx-size", str(args.ctx_size),
            "--n-gpu-layers", str(args.n_gpu_layers),
        ]
        if args.threads is not None:
            command.extend(["--threads", str(args.threads)])

        print("\nStarting llama.cpp server...")
        print(f"Model: {model}")
        print("Server command:")
        print("  " + subprocess.list2cmdline(command))
        # Let llama.cpp write its load/runtime logs directly to this console.
        process = subprocess.Popen(command)
        wait_for_upstream(process, args.upstream_host, args.upstream_port, args.startup_timeout)

        # Fetch the authoritative ID exposed by llama.cpp, not a guessed filename.
        model_id = None
        model_id_error = None
        model_id_deadline = time.monotonic() + 30
        while time.monotonic() < model_id_deadline:
            try:
                model_id = fetch_model_id(args.upstream_host, args.upstream_port)
                break
            except Exception as exc:
                model_id_error = str(exc)
                if process.poll() is not None:
                    raise RuntimeError(
                        f"llama-server exited while retrieving its model ID: {model_id_error}"
                    )
                time.sleep(1)

        if not model_id:
            raise RuntimeError(
                "llama-server became reachable, but its /v1/models endpoint did not "
                f"provide a model ID: {model_id_error}"
            )

        # Query GET /props for the effective context actually loaded by llama.cpp.
        # This is best-effort: older server builds may not expose this endpoint.
        context_info = None
        context_error = None
        context_deadline = time.monotonic() + 30
        while time.monotonic() < context_deadline:
            try:
                context_info = fetch_context_info(args.upstream_host, args.upstream_port)
                break
            except Exception as exc:
                context_error = str(exc)
                if process.poll() is not None:
                    raise RuntimeError(
                        f"llama-server exited while scanning its context window: {context_error}"
                    )
                time.sleep(1)

        if context_info is None:
            print(f"\n[context scanner] Could not read loaded context from /props: {context_error}")

        cors_origins = tuple(DEFAULT_CORS_ORIGINS) + tuple(args.cors_origins or ())
        handler = make_proxy_handler(
            args.upstream_host, args.upstream_port, api_key, cors_origins=cors_origins
        )
        proxy = ThreadingHTTPServer((args.proxy_host, args.proxy_port), handler)
        proxy.daemon_threads = True
        proxy_thread = threading.Thread(target=proxy.serve_forever, name="api-key-proxy", daemon=True)
        proxy_thread.start()

        display_host = "127.0.0.1" if args.proxy_host in {"0.0.0.0", "::"} else args.proxy_host
        print("\nProxy is ready.")
        print(f"Model ID:  {model_id}")
        print(f"Base URL:  http://{display_host}:{args.proxy_port}/v1")
        print(f"Chat URL:  http://{display_host}:{args.proxy_port}/v1/chat/completions")
        print(f"Models:    http://{display_host}:{args.proxy_port}/v1/models")
        print(f"Health:    http://{display_host}:{args.proxy_port}/health")
        print(f"API key:   {api_key}")
        print("Auth:      Authorization: Bearer <API_KEY>  (or X-API-Key: <API_KEY>)")
        print("CORS:      Single-origin headers for: " + ", ".join(cors_origins))
        print("Janitor AI: Use the Chat URL above and the exact Model ID shown here.")
        print_context_scan(context_info, args.ctx_size)
        if args.proxy_host == "0.0.0.0":
            print("WARNING: Proxy is listening on all network interfaces. Restrict access with your firewall.")

        if args.no_chat:
            print("\nAPI server running. Press Ctrl+C to stop both servers.")
            while process.poll() is None:
                time.sleep(1)
            print(f"llama-server exited with code {process.returncode}.")
            return process.returncode or 0

        start_chat_test(args.proxy_host, args.proxy_port, api_key, args.system_prompt, model_id)
        return 0

    except KeyboardInterrupt:
        print("\nStopping...")
        return 130
    except Exception as exc:
        print(f"\nERROR: {exc}", file=sys.stderr)
        return 1
    finally:
        if proxy is not None:
            proxy.shutdown()
            proxy.server_close()
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5)


if __name__ == "__main__":
    raise SystemExit(main())
