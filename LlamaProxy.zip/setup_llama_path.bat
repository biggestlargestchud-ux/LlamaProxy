@echo off
setlocal

REM Add the folder containing this script's llama-server.exe to the current user's PATH.
set "LLAMA_DIR=%~dp0"

if not exist "%LLAMA_DIR%llama-server.exe" (
    echo ERROR: llama-server.exe was not found in:
    echo   "%LLAMA_DIR%"
    echo.
    echo Put this BAT file in the same folder as llama-server.exe, then run it again.
    pause
    exit /b 1
)

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference = 'Stop'; $dir = [IO.Path]::GetFullPath($env:LLAMA_DIR); $old = [Environment]::GetEnvironmentVariable('Path', 'User'); $parts = @($old -split ';' | Where-Object { $_ -ne '' }); $exists = $false; foreach ($p in $parts) { if ([string]::Equals($p.TrimEnd('\'), $dir.TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { $exists = $true; break } }; if (-not $exists) { $new = if ([string]::IsNullOrEmpty($old)) { $dir } else { $old.TrimEnd(';') + ';' + $dir }; [Environment]::SetEnvironmentVariable('Path', $new, 'User'); Write-Output ('Added to User PATH: ' + $dir) } else { Write-Output ('Already present in User PATH: ' + $dir) }"

if errorlevel 1 (
    echo.
    echo ERROR: Could not update User PATH.
    pause
    exit /b 1
)

REM Also make it available in this batch process and any child processes it starts.
set "PATH=%PATH%;%LLAMA_DIR%"

echo.
echo SUCCESS: llama-server.exe is set up in your User PATH.
echo Open a NEW terminal window, then test with:
echo   llama-server --version
echo.
pause
endlocal
